var content=(function(){function e(e){return e}var t={es:{app_name:`RecordFlow`,app_tagline:`Grabador local e ilimitado de pantalla y cámara`,unlimited_badge:`100% Local • Ilimitado`,loom_alt:`Alternativa Libre a Loom`,status_ready:`Listo`,status_recording:`Grabando`,tab_record:`Grabador`,tab_recent:`Grabaciones Recientes`,mode_screen_camera:`Pantalla + Cámara`,mode_screen_only:`Solo Pantalla`,mode_camera_only:`Solo Cámara`,mode_screen_camera_desc:`Graba la pantalla con tu cámara en burbuja circular flotante`,mode_screen_only_desc:`Graba toda la pantalla, ventana o pestaña seleccionada`,mode_camera_only_desc:`Graba exclusivamente tu cámara web`,audio_mic_label:`Micrófono`,audio_mic_active:`Activo`,audio_mic_muted:`Silenciado`,audio_mic_desc:`Incluir voz desde el micrófono en la grabación`,btn_start_recording:`Iniciar Grabación`,btn_stop_recording:`Detener Grabación`,btn_finish_recording:`Finalizar`,btn_cancel:`Cancelar`,btn_download_video:`Descargar Video (.webm)`,btn_download_mp4:`Descargar Video (.mp4)`,btn_download_webm:`Descargar Video (.webm)`,btn_copy_link:`Copiar Enlace Local`,btn_link_copied:`¡Enlace copiado!`,btn_record_new:`Grabar Nuevo Video`,btn_delete:`Eliminar`,btn_rename:`Renombrar`,btn_save:`Guardar`,floating_recording:`REC`,floating_paused:`PAUSA`,floating_finish:`Finalizar`,floating_pause:`Pausar`,floating_resume:`Reanudar`,floating_mute:`Silenciar mic`,floating_unmute:`Activar mic`,floating_cam_hide:`Ocultar cámara`,floating_cam_show:`Mostrar cámara`,floating_size:`Tamaño`,floating_discard:`Descartar`,confirm_discard:`¿Descartar esta grabación sin guardar?`,camera_preview_title:`Vista previa de cámara`,camera_preview_hint:`Comprueba tu iluminación y encuadre`,camera_preview_error:`No se pudo acceder a la cámara para la vista previa`,vu_meter_label:`Nivel de entrada`,playback_speed:`Velocidad`,no_recordings_title:`No hay grabaciones guardadas`,no_recordings_desc:`Tus videos se guardan 100% en tu navegador, sin límites ni nubes de terceros.`,meta_duration:`Duración`,meta_size:`Tamaño`,meta_date:`Fecha`,meta_mode:`Modo`,confirm_delete:`¿Estás seguro de que deseas eliminar esta grabación? Esta acción no se puede deshacer.`,preview_header_title:`RecordFlow Studio`,preview_subtitle:`Grabación completada con éxito • Almacenamiento local`,preview_player_title:`Reproductor de Video`,preview_file_details:`Detalles del Archivo`,preview_all_recordings:`Tus Grabaciones Guardadas`,preview_format:`Formato WebM de alta fidelidad`,err_restricted_page:`Por favor abre una página web regular (HTTP/HTTPS) para grabar.`,err_permission_denied:`Permiso de pantalla o cámara denegado.`,err_recording_failed:`Ocurrió un error al iniciar la grabación.`,notice_recording_active:`Grabación en curso en la pestaña activa...`,universal_studio_title:`RecordFlow Studio — Grabador Universal`,universal_studio_subtitle:`Graba cualquier pantalla, ventana o aplicación del equipo`,universal_status_recording:`Grabando pantalla...`,universal_instructions:`Puedes minimizar esta pestaña y trabajar en cualquier aplicación de tu equipo (VS Code, terminal, juegos, etc.). Cuando termines, haz clic en Detener o usa el botón 'Dejar de compartir' de Chrome.`,universal_btn_stop_save:`Detener y Guardar Grabación`,universal_prompt_title:`Estudio de Grabación Universal`,universal_prompt_desc:`Graba cualquier aplicación, ventana o tu pantalla completa sin restricciones.`,universal_btn_start_share:`Seleccionar Pantalla y Comenzar`,universal_cancelled_title:`Selección Cancelada`,universal_cancelled_desc:`No se seleccionó ninguna pantalla o se canceló el permiso. Puedes reintentar cuando desees.`,universal_btn_retry:`Reintentar Selección`,open_universal_studio:`O abrir Estudio Universal para grabar cualquier app`,launch_floating_studio:`Abrir Estudio Flotante en la página`,floating_hub_title:`Estudio Flotante`,floating_launcher_tooltip:`Grabar pantalla con RecordFlow`,floating_launcher_hide:`Ocultar botón flotante`,developed_by:`Desarrollado por`},en:{app_name:`RecordFlow`,app_tagline:`Local-first & unlimited screen and camera recorder`,unlimited_badge:`100% Local • Unlimited`,loom_alt:`Free Loom Alternative`,status_ready:`Ready`,status_recording:`Recording`,tab_record:`Recorder`,tab_recent:`Recent Recordings`,mode_screen_camera:`Screen + Camera`,mode_screen_only:`Screen Only`,mode_camera_only:`Camera Only`,mode_screen_camera_desc:`Record screen with circular floating webcam bubble`,mode_screen_only_desc:`Record full screen, window, or selected tab`,mode_camera_only_desc:`Record webcam video exclusively`,audio_mic_label:`Microphone`,audio_mic_active:`Active`,audio_mic_muted:`Muted`,audio_mic_desc:`Include voice from microphone in recording`,btn_start_recording:`Start Recording`,btn_stop_recording:`Stop Recording`,btn_finish_recording:`Finish`,btn_cancel:`Cancel`,btn_download_video:`Download Video (.webm)`,btn_download_mp4:`Download Video (.mp4)`,btn_download_webm:`Download Video (.webm)`,btn_copy_link:`Copy Local Link`,btn_link_copied:`Link copied!`,btn_record_new:`Record New Video`,btn_delete:`Delete`,btn_rename:`Rename`,btn_save:`Save`,floating_recording:`REC`,floating_paused:`PAUSED`,floating_finish:`Finish`,floating_pause:`Pause`,floating_resume:`Resume`,floating_mute:`Mute mic`,floating_unmute:`Unmute mic`,floating_cam_hide:`Hide camera`,floating_cam_show:`Show camera`,floating_size:`Size`,floating_discard:`Discard`,confirm_discard:`Discard this recording without saving?`,camera_preview_title:`Live Camera Preview`,camera_preview_hint:`Check your framing and lighting`,camera_preview_error:`Unable to access camera for preview`,vu_meter_label:`Input level`,playback_speed:`Speed`,no_recordings_title:`No saved recordings yet`,no_recordings_desc:`Your videos are saved 100% locally in your browser with zero caps.`,meta_duration:`Duration`,meta_size:`Size`,meta_date:`Date`,meta_mode:`Mode`,confirm_delete:`Are you sure you want to delete this recording? This action cannot be undone.`,preview_header_title:`RecordFlow Studio`,preview_subtitle:`Recording finished successfully • Local storage`,preview_player_title:`Video Player`,preview_file_details:`File Details`,preview_all_recordings:`Your Saved Recordings`,preview_format:`High-fidelity WebM container`,err_restricted_page:`Please navigate to a regular web page (HTTP/HTTPS) to record.`,err_permission_denied:`Screen or camera permission was denied.`,err_recording_failed:`An error occurred while starting the recording.`,notice_recording_active:`Recording in progress on active tab...`,universal_studio_title:`RecordFlow Studio — Universal Recorder`,universal_studio_subtitle:`Record any screen, window, or desktop application`,universal_status_recording:`Recording screen...`,universal_instructions:`You can minimize this tab and work in any application on your computer (VS Code, terminal, games, etc.). When you're done, click Stop or use Chrome's 'Stop sharing' button.`,universal_btn_stop_save:`Stop and Save Recording`,universal_prompt_title:`Universal Studio Recorder`,universal_prompt_desc:`Record any application, window, or your entire screen without page restrictions.`,universal_btn_start_share:`Select Screen & Start`,universal_cancelled_title:`Selection Cancelled`,universal_cancelled_desc:`No screen was selected or permission was cancelled. You can retry whenever you are ready.`,universal_btn_retry:`Retry Selection`,open_universal_studio:`Or open Universal Studio to record any app`,launch_floating_studio:`Open Floating Studio on page`,floating_hub_title:`Floating Studio`,floating_launcher_tooltip:`Record screen with RecordFlow`,floating_launcher_hide:`Hide floating button`,developed_by:`Developed by`}},n=`recordflow_lang`;async function r(){try{let e=await chrome.storage.local.get(n);if(e[n]===`es`||e[n]===`en`)return e[n]}catch{}return navigator.language.toLowerCase().startsWith(`es`)?`es`:`en`}function i(e,n=`es`){return t[n]?.[e]||t.en[e]||e}function a(e){let t=Math.floor(e/60),n=Math.floor(e%60);return`${t.toString().padStart(2,`0`)}:${n.toString().padStart(2,`0`)}`}function o(e,t=`es`){return new Date(e).toLocaleString(t===`es`?`es-ES`:`en-US`,{month:`short`,day:`numeric`,hour:`2-digit`,minute:`2-digit`})}var s=`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-video"><path d="m22 8-6 4 6 4V8Z"/><rect width="14" height="12" x="2" y="6" rx="2" ry="2"/></svg>`,c=`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-camera"><path d="M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3z"/><circle cx="12" cy="13" r="3"/></svg>`,l=`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-monitor"><rect width="20" height="14" x="2" y="3" rx="2"/><line x1="8" x2="16" y1="21" y2="21"/><line x1="12" x2="12" y1="17" y2="21"/></svg>`,u=`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-monitor-camera"><rect width="14" height="11" x="1" y="3" rx="2"/><line x1="4" x2="12" y1="18" y2="18"/><line x1="8" x2="8" y1="14" y2="18"/><rect width="7" height="6" x="15" y="11" rx="1.5"/><path d="m22 12.5 1.5-1v5l-1.5-1"/></svg>`,d=`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-mic"><path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" x2="12" y1="19" y2="22"/></svg>`,f=`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-mic-off"><line x1="2" x2="22" y1="2" y2="22"/><path d="M18.89 13.23A7.12 7.12 0 0 0 19 12v-2"/><path d="M5 10v2a7 7 0 0 0 12 5"/><path d="M15 9.34V5a3 3 0 0 0-5.68-1.33"/><path d="M9 9v3a3 3 0 0 0 5.12 2.12"/><line x1="12" x2="12" y1="19" y2="22"/></svg>`,p=`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-pause"><rect width="4" height="16" x="6" y="4" rx="1"/><rect width="4" height="16" x="14" y="4" rx="1"/></svg>`,m=`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-eye"><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></svg>`,h=`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-eye-off"><path d="M10.733 5.076a10.744 10.744 0 0 1 11.205 6.575 1 1 0 0 1 0 .698 10.793 10.793 0 0 1-3.79 4.887"/><path d="M14.084 14.158a3 3 0 0 1-4.242-4.242"/><path d="M17.479 17.499A10.75 10.75 0 0 1 12 19c-7 0-10-7-10-7a13.16 13.16 0 0 1 2.16-3.237"/><path d="m2 2 20 20"/></svg>`,g=`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-x"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>`,_=`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-trash-2"><path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/><line x1="10" x2="10" y1="11" y2="17"/><line x1="14" x2="14" y1="11" y2="17"/></svg>`,v=`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-play"><polygon points="6 3 20 12 6 21 6 3"/></svg>`,y=`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-square"><rect width="18" height="18" x="3" y="3" rx="2"/></svg>`,b=e({matches:[`<all_urls>`],runAt:`document_idle`,main(){let e=null,t=[],n=null,b=null,x=null,S=!1,C=!1,w=0,T=0,E=0,D=null,O=null,k=null,A=null,j=null,M=`m`,N=!1,P=!1,F=100,I=typeof window<`u`?Math.max(80,window.innerHeight-230):400,L=null,R=null,z=null,B=null,V=null,H=null,U=null,W=null,G=`screen-camera`,K=!0,q=!0;function ee(){for(let e of[`video/webm;codecs=vp9,opus`,`video/webm;codecs=vp8,opus`,`video/webm;codecs=h264,opus`,`video/webm`])if(typeof MediaRecorder<`u`&&MediaRecorder.isTypeSupported(e))return e;return`video/webm`}function te(){let e=[D,O,k,A];for(let t of e)t&&t.getTracks().forEach(e=>{try{e.stop(),e.enabled=!1}catch{}});if(D=null,O=null,k=null,A=null,j&&j.state!==`closed`){try{j.close()}catch{}j=null}}function J(){x&&=(clearInterval(x),null),n&&n.parentNode&&n.parentNode.removeChild(n),n=null,b=null}function ne(){if(W&&=(cancelAnimationFrame(W),null),B&&=(B.getTracks().forEach(e=>{try{e.stop()}catch{}}),null),V&&=(V.getTracks().forEach(e=>{try{e.stop()}catch{}}),null),H&&H.state!==`closed`){try{H.close()}catch{}H=null}U=null}function Y(){z&&z.parentNode&&z.parentNode.removeChild(z),z=null}function X(){R&&R.parentNode&&R.parentNode.removeChild(R),R=null}function re(){Y(),ne(),X()}function ie(e){Y(),z=document.createElement(`div`),z.id=`recordflow-prebubble-host`,z.style.position=`fixed`,z.style.zIndex=`2147483647`,z.style.top=`0`,z.style.left=`0`,z.style.width=`100vw`,z.style.height=`100vh`,z.style.pointerEvents=`none`;let t=z.attachShadow({mode:`open`}),n=document.createElement(`style`);n.textContent=`
        * {
          box-sizing: border-box;
          margin: 0;
          padding: 0;
          user-select: none;
        }

        .camera-bubble-wrapper {
          position: fixed;
          pointer-events: auto;
          cursor: grab;
          z-index: 2147483647 !important;
          transition: opacity 0.2s ease, transform 0.2s ease;
        }

        .camera-bubble-wrapper:active {
          cursor: grabbing;
        }

        .camera-bubble {
          width: 175px;
          height: 175px;
          border-radius: 50%;
          overflow: hidden;
          background: #0f172a;
          border: 3.5px solid #6366f1;
          box-shadow: 
            0 0 25px rgba(99, 102, 241, 0.55),
            0 12px 36px rgba(0, 0, 0, 0.45);
          position: relative;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .camera-video {
          width: 100%;
          height: 100%;
          object-fit: cover;
          transform: scaleX(-1);
        }

        .btn-bubble-pip {
          position: absolute;
          top: 10px;
          right: 14px;
          width: 26px;
          height: 26px;
          border-radius: 50%;
          background: rgba(15, 23, 42, 0.85);
          border: 1px solid rgba(255, 255, 255, 0.25);
          color: #ffffff;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          opacity: 0;
          transition: opacity 0.15s ease, transform 0.15s ease;
          z-index: 10;
        }

        .camera-bubble-wrapper:hover .btn-bubble-pip {
          opacity: 1;
        }

        .btn-bubble-pip:hover {
          transform: scale(1.1);
          background: #6366f1;
        }

        .prebubble-badge {
          position: absolute;
          bottom: 8px;
          background: rgba(15, 23, 42, 0.85);
          border: 1px solid rgba(255, 255, 255, 0.2);
          border-radius: 9999px;
          padding: 2px 8px;
          font-size: 10px;
          font-weight: 700;
          color: #a5b4fc;
          letter-spacing: 0.04em;
          text-transform: uppercase;
          pointer-events: none;
        }
      `,t.appendChild(n);let r=document.createElement(`div`);r.className=`camera-bubble-wrapper`;let i=document.createElement(`div`);i.className=`camera-bubble`;let a=document.createElement(`video`);a.className=`camera-video`,a.autoplay=!0,a.muted=!0,a.defaultMuted=!0,a.playsInline=!0,a.setAttribute(`autoplay`,``),a.setAttribute(`playsinline`,``),a.setAttribute(`muted`,``);let o=document.createElement(`span`);o.className=`prebubble-badge`,o.textContent=`RecordFlow`,i.appendChild(a),i.appendChild(o),r.appendChild(i),r.style.left=`${F}px`,r.style.top=`${I}px`,t.appendChild(r),document.body.appendChild(z),a.srcObject=e,a.onloadedmetadata=()=>{a.play().catch(()=>{})},a.play().catch(()=>{});let s=!1,c=0,l=0;r.addEventListener(`pointerdown`,e=>{s=!0,c=e.clientX-F,l=e.clientY-I,r.setPointerCapture(e.pointerId)}),r.addEventListener(`pointermove`,e=>{if(!s)return;let t=e.clientX-c,n=e.clientY-l,i=r.getBoundingClientRect(),a=window.innerWidth-i.width-8,o=window.innerHeight-i.height-8;F=Math.max(8,Math.min(t,a)),I=Math.max(8,Math.min(n,o)),r.style.left=`${F}px`,r.style.top=`${I}px`});let u=e=>{if(s){s=!1;try{r.releasePointerCapture(e.pointerId)}catch{}}};r.addEventListener(`pointerup`,u),r.addEventListener(`pointercancel`,u)}function Z(e){try{let t=window.AudioContext||window.webkitAudioContext;if(!t)return;let n=new t,r=n.createOscillator(),i=n.createGain();r.type=`sine`,r.frequency.setValueAtTime(e,n.currentTime),i.gain.setValueAtTime(.1,n.currentTime),i.gain.exponentialRampToValueAtTime(.001,n.currentTime+.16),r.connect(i),i.connect(n.destination),r.start(),r.stop(n.currentTime+.16)}catch{}}async function Q(t){if(S)return;S=!0,x&&=(clearInterval(x),null);let n=C?w:w+(Date.now()-T);E=Math.max(1,Math.round(n/1e3)),e&&e.state!==`inactive`?e.stop():await ae(t)}async function ae(n){te(),J();let a=ee(),s=new Blob(t,{type:a}),c=`rf_${Date.now()}_${Math.random().toString(36).substring(2,7)}`,l=await r(),u=`${i(`app_name`,l)} — ${o(Date.now(),l)}`;try{let e=new FileReader;e.onloadend=()=>{let t=e.result;chrome.runtime.sendMessage({type:`RECORDING_FINISHED`,id:c,title:u,duration:E,size:s.size,mode:n,mimeType:a,dataUrl:t})},e.readAsDataURL(s)}catch(e){console.error(`[RecordFlow] Failed to save recording:`,e)}finally{t=[],e=null,S=!1,C=!1}}function oe(){te(),J(),t=[],e=null,S=!1,C=!1,chrome.runtime.sendMessage({type:`RECORDING_CANCELLED`})}function se(e){J(),n=document.createElement(`div`),n.id=`recordflow-overlay-root`,n.style.position=`fixed`,n.style.zIndex=`2147483640`,n.style.top=`0`,n.style.left=`0`,n.style.width=`100vw`,n.style.height=`100vh`,n.style.pointerEvents=`none`,b=n.attachShadow({mode:`open`});let t=document.createElement(`style`);t.textContent=`
        * {
          box-sizing: border-box;
          margin: 0;
          padding: 0;
          font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
          user-select: none;
        }

        .countdown-backdrop {
          position: fixed;
          top: 0;
          left: 0;
          width: 100vw;
          height: 100vh;
          display: flex;
          align-items: center;
          justify-content: center;
          background: rgba(15, 23, 42, 0.45);
          backdrop-filter: blur(8px);
          -webkit-backdrop-filter: blur(8px);
          pointer-events: auto;
          transition: opacity 0.25s ease-out;
        }

        .countdown-card {
          width: 160px;
          height: 160px;
          border-radius: 40px;
          background: rgba(15, 23, 42, 0.9);
          border: 1.5px solid rgba(255, 255, 255, 0.2);
          box-shadow: 
            0 20px 50px rgba(0, 0, 0, 0.6),
            0 0 35px rgba(99, 102, 241, 0.4);
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          gap: 6px;
        }

        .countdown-number {
          font-size: 72px;
          font-weight: 800;
          color: #ffffff;
          line-height: 1;
          font-variant-numeric: tabular-nums;
          animation: pop-digit 0.9s cubic-bezier(0.16, 1, 0.3, 1) forwards;
          text-shadow: 0 0 20px rgba(99, 102, 241, 0.8);
        }

        .countdown-label {
          font-size: 11.5px;
          font-weight: 600;
          text-transform: uppercase;
          letter-spacing: 0.1em;
          color: #a5b4fc;
        }

        @keyframes pop-digit {
          0% {
            opacity: 0;
            transform: scale(1.6);
          }
          40% {
            opacity: 1;
            transform: scale(1);
          }
          85% {
            opacity: 1;
            transform: scale(0.96);
          }
          100% {
            opacity: 0;
            transform: scale(0.8);
          }
        }
      `,b.appendChild(t);let r=document.createElement(`div`);r.className=`countdown-backdrop`;let i=document.createElement(`div`);i.className=`countdown-card`;let a=document.createElement(`span`);a.className=`countdown-number`,a.textContent=`3`;let o=document.createElement(`span`);o.className=`countdown-label`,o.textContent=`RecordFlow`,i.appendChild(a),i.appendChild(o),r.appendChild(i),b.appendChild(r),document.body.appendChild(n);let s=3;Z(520);let c=window.setInterval(()=>{s--,s>0?(Z(520),a.style.animation=`none`,a.offsetWidth,a.style.animation=`pop-digit 0.9s cubic-bezier(0.16, 1, 0.3, 1) forwards`,a.textContent=s.toString()):(clearInterval(c),Z(880),r.style.opacity=`0`,setTimeout(()=>{e()},200))},1e3)}function ce(t,r,o){J(),n=document.createElement(`div`),n.id=`recordflow-overlay-root`,n.style.position=`fixed`,n.style.zIndex=`2147483647`,n.style.pointerEvents=`none`,n.style.top=`0`,n.style.left=`0`,n.style.width=`100vw`,n.style.height=`100vh`,b=n.attachShadow({mode:`open`});let s=document.createElement(`style`);s.textContent=`
        * {
          box-sizing: border-box;
          margin: 0;
          padding: 0;
          font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
          user-select: none;
        }

        /* Circular Webcam Bubble */
        .camera-bubble-wrapper {
          position: fixed;
          bottom: 36px;
          left: 100px;
          pointer-events: auto;
          cursor: grab;
          z-index: 2147483647 !important;
          transition: opacity 0.2s cubic-bezier(0.16, 1, 0.3, 1), transform 0.2s cubic-bezier(0.16, 1, 0.3, 1);
        }

        .camera-bubble-wrapper:active {
          cursor: grabbing;
        }

        .camera-bubble-wrapper.hidden-bubble {
          opacity: 0;
          pointer-events: none;
          transform: scale(0.7);
        }

        .btn-bubble-pip {
          position: absolute;
          top: 10px;
          right: 14px;
          width: 26px;
          height: 26px;
          border-radius: 50%;
          background: rgba(15, 23, 42, 0.85);
          border: 1px solid rgba(255, 255, 255, 0.25);
          color: #ffffff;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          opacity: 0;
          transition: opacity 0.15s ease, transform 0.15s ease;
          z-index: 10;
        }

        .camera-bubble-wrapper:hover .btn-bubble-pip {
          opacity: 1;
        }

        .btn-bubble-pip:hover {
          transform: scale(1.1);
          background: #6366f1;
        }

        .camera-bubble {
          border-radius: 50%;
          overflow: hidden;
          background: #0f172a;
          border: 3.5px solid #6366f1;
          box-shadow: 
            0 0 25px rgba(99, 102, 241, 0.55),
            0 12px 36px rgba(0, 0, 0, 0.45);
          position: relative;
          display: flex;
          align-items: center;
          justify-content: center;
          transform: translateZ(0);
          transition: width 0.25s cubic-bezier(0.16, 1, 0.3, 1), height 0.25s cubic-bezier(0.16, 1, 0.3, 1);
        }

        .camera-bubble.size-s {
          width: 120px;
          height: 120px;
        }

        .camera-bubble.size-m {
          width: 175px;
          height: 175px;
        }

        .camera-bubble.size-l {
          width: 240px;
          height: 240px;
        }

        .camera-video {
          width: 100%;
          height: 100%;
          object-fit: cover;
          transform: scaleX(-1);
        }

        /* Loom-Style Vertical Liquid Glass Control Dock (Left Edge) */
        .loom-dock {
          position: fixed;
          left: 24px;
          top: 50%;
          transform: translateY(-50%);
          background: rgba(15, 23, 42, 0.92);
          backdrop-filter: blur(24px);
          -webkit-backdrop-filter: blur(24px);
          border: 1.5px solid rgba(255, 255, 255, 0.16);
          border-radius: 36px;
          padding: 10px 8px;
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 10px;
          box-shadow: 
            0 15px 40px rgba(0, 0, 0, 0.65),
            0 0 25px rgba(99, 102, 241, 0.3);
          color: #ffffff;
          pointer-events: auto;
          cursor: grab;
          z-index: 2147483647;
          transition: box-shadow 0.2s ease, border-color 0.2s ease;
        }

        .loom-dock:active {
          cursor: grabbing;
        }

        .loom-dock.is-paused {
          border-color: rgba(245, 158, 11, 0.6);
          box-shadow: 
            0 15px 40px rgba(0, 0, 0, 0.65),
            0 0 25px rgba(245, 158, 11, 0.3);
        }

        /* Big Red Stop Button */
        .btn-stop-dock {
          width: 44px;
          height: 44px;
          border-radius: 50%;
          background: #ef4444;
          border: 2px solid rgba(255, 255, 255, 0.3);
          color: #ffffff;
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
          box-shadow: 0 0 16px rgba(239, 68, 68, 0.7);
          transition: all 0.15s ease;
        }

        .btn-stop-dock:hover {
          transform: scale(1.08);
          background: #dc2626;
          box-shadow: 0 0 22px rgba(239, 68, 68, 0.9);
        }

        .btn-stop-dock:active {
          transform: scale(0.95);
        }

        .btn-stop-dock svg {
          width: 18px;
          height: 18px;
          fill: currentColor;
          stroke: none;
        }

        /* Live Timer Badge */
        .dock-timer-badge {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 3px;
          padding: 2px 4px;
        }

        .rec-dot {
          width: 7px;
          height: 7px;
          background-color: #ef4444;
          border-radius: 50%;
          animation: pulse-dot 1.2s infinite ease-in-out;
          box-shadow: 0 0 8px rgba(239, 68, 68, 0.9);
        }

        .is-paused .rec-dot {
          background-color: #f59e0b;
          box-shadow: 0 0 8px rgba(245, 158, 11, 0.9);
        }

        @keyframes pulse-dot {
          0%, 100% { opacity: 1; transform: scale(1); }
          50% { opacity: 0.35; transform: scale(0.85); }
        }

        .timer-display {
          font-size: 11.5px;
          font-weight: 800;
          font-variant-numeric: tabular-nums;
          font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
          color: #f8fafc;
          letter-spacing: 0.02em;
        }

        .dock-divider-h {
          width: 24px;
          height: 1px;
          background: rgba(255, 255, 255, 0.14);
          margin: 2px 0;
        }

        /* Action Buttons inside Dock */
        .btn-dock-action {
          background: rgba(255, 255, 255, 0.08);
          border: 1px solid rgba(255, 255, 255, 0.12);
          color: #f1f5f9;
          border-radius: 50%;
          width: 36px;
          height: 36px;
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
          transition: all 0.15s ease;
          position: relative;
        }

        .btn-dock-action:hover {
          background: rgba(255, 255, 255, 0.2);
          border-color: rgba(255, 255, 255, 0.35);
          transform: scale(1.08);
        }

        .btn-dock-action:active {
          transform: scale(0.92);
        }

        .btn-dock-action svg {
          width: 17px;
          height: 17px;
          stroke: currentColor;
        }

        .btn-dock-action.active {
          background: rgba(99, 102, 241, 0.3);
          border-color: #6366f1;
          color: #a5b4fc;
        }

        .btn-dock-action.muted {
          background: rgba(239, 68, 68, 0.2);
          border-color: rgba(239, 68, 68, 0.5);
          color: #fca5a5;
        }

        .btn-size-toggle {
          font-size: 11px;
          font-weight: 800;
          color: #c7d2fe;
          background: rgba(99, 102, 241, 0.2);
          border: 1px solid rgba(99, 102, 241, 0.4);
        }

        .btn-discard-dock:hover {
          background: rgba(239, 68, 68, 0.25);
          border-color: rgba(239, 68, 68, 0.5);
          color: #fca5a5;
        }
      `,b.appendChild(s);let c=null,l=null;if(t&&(r===`screen-camera`||r===`camera`)){c=document.createElement(`div`),c.className=`camera-bubble-wrapper`,l=document.createElement(`div`),l.className=`camera-bubble size-${M}`;let e=document.createElement(`video`);e.className=`camera-video`,e.autoplay=!0,e.muted=!0,e.playsInline=!0,e.srcObject=t,e.play().catch(()=>{}),l.appendChild(e),c.appendChild(l);let n=!1,r=0,i=0,a=F,o=I;c.style.left=`${a}px`,c.style.top=`${o}px`,c.style.bottom=`auto`,c.addEventListener(`pointerdown`,e=>{n=!0,r=e.clientX-a,i=e.clientY-o,c.setPointerCapture(e.pointerId)}),c.addEventListener(`pointermove`,e=>{if(!n)return;let t=e.clientX-r,s=e.clientY-i,l=c.getBoundingClientRect(),u=window.innerWidth-l.width-8,d=window.innerHeight-l.height-8;a=Math.max(8,Math.min(t,u)),o=Math.max(8,Math.min(s,d)),F=a,I=o,c.style.left=`${a}px`,c.style.top=`${o}px`});let s=e=>{if(n){n=!1;try{c.releasePointerCapture(e.pointerId)}catch{}}};c.addEventListener(`pointerup`,s),c.addEventListener(`pointercancel`,s),b.appendChild(c)}let u=document.createElement(`div`);u.className=`loom-dock`;let g=document.createElement(`button`);g.className=`btn-stop-dock`,g.title=i(`btn_stop_recording`,o),g.innerHTML=y,g.addEventListener(`click`,e=>{e.stopPropagation(),Q(r)}),u.appendChild(g);let S=document.createElement(`div`);S.className=`dock-timer-badge`;let E=document.createElement(`span`);E.className=`rec-dot`;let D=document.createElement(`span`);D.className=`timer-display`,D.textContent=`00:00`,S.appendChild(E),S.appendChild(D),u.appendChild(S);let O=document.createElement(`div`);O.className=`dock-divider-h`,u.appendChild(O);let A=document.createElement(`button`);A.className=`btn-dock-action`,A.title=i(`floating_pause`,o),A.innerHTML=p,A.addEventListener(`click`,t=>{t.stopPropagation(),e&&(C?(e.resume(),C=!1,T=Date.now(),u.classList.remove(`is-paused`),A.innerHTML=p,A.title=i(`floating_pause`,o)):(e.pause(),C=!0,w+=Date.now()-T,u.classList.add(`is-paused`),A.innerHTML=v,A.title=i(`floating_resume`,o)))}),u.appendChild(A);let j=document.createElement(`button`);if(j.className=`btn-dock-action`,j.title=i(`floating_mute`,o),j.innerHTML=d,j.addEventListener(`click`,e=>{e.stopPropagation(),P=!P,k&&k.getAudioTracks().forEach(e=>{e.enabled=!P}),P?(j.classList.add(`muted`),j.innerHTML=f,j.title=i(`floating_unmute`,o)):(j.classList.remove(`muted`),j.innerHTML=d,j.title=i(`floating_mute`,o))}),u.appendChild(j),c){let e=document.createElement(`button`);e.className=`btn-dock-action`,e.title=i(`floating_cam_hide`,o),e.innerHTML=m,e.addEventListener(`click`,t=>{t.stopPropagation(),N=!N,N?(c.classList.add(`hidden-bubble`),e.innerHTML=h,e.title=i(`floating_cam_show`,o)):(c.classList.remove(`hidden-bubble`),e.innerHTML=m,e.title=i(`floating_cam_hide`,o))}),u.appendChild(e);let t=document.createElement(`button`);t.className=`btn-dock-action btn-size-toggle`,t.title=i(`floating_size`,o),t.textContent=`M`,t.addEventListener(`click`,e=>{e.stopPropagation(),M===`s`?(M=`m`,l.className=`camera-bubble size-m`,t.textContent=`M`):M===`m`?(M=`l`,l.className=`camera-bubble size-l`,t.textContent=`L`):(M=`s`,l.className=`camera-bubble size-s`,t.textContent=`S`)}),u.appendChild(t);let n=document.createElement(`button`);n.className=`btn-dock-action`,n.title=`Flotar cámara sobre todas las pestañas (PiP)`,n.innerHTML=`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width:16px;height:16px"><rect width="18" height="18" x="3" y="3" rx="2"/><path d="M15 13h5v5h-5z"/></svg>`,n.addEventListener(`click`,e=>{e.stopPropagation();let t=l?.querySelector(`video`);document.pictureInPictureElement?document.exitPictureInPicture().catch(()=>{}):t&&t.requestPictureInPicture().catch(()=>{})}),u.appendChild(n)}let L=document.createElement(`div`);L.className=`dock-divider-h`,u.appendChild(L);let R=document.createElement(`button`);R.className=`btn-dock-action btn-discard-dock`,R.title=i(`floating_discard`,o),R.innerHTML=_,R.addEventListener(`click`,e=>{e.stopPropagation(),confirm(i(`confirm_discard`,o))&&oe()}),u.appendChild(R);let z=!1,B=0,V=0,H=24,U=Math.max(80,window.innerHeight/2-160);u.style.left=`${H}px`,u.style.top=`${U}px`,u.style.transform=`none`,u.addEventListener(`pointerdown`,e=>{e.target.closest(`button`)||(z=!0,B=e.clientX-H,V=e.clientY-U,u.setPointerCapture(e.pointerId))}),u.addEventListener(`pointermove`,e=>{if(!z)return;let t=e.clientX-B,n=e.clientY-V,r=u.getBoundingClientRect(),i=window.innerWidth-r.width-12,a=window.innerHeight-r.height-12;H=Math.max(12,Math.min(t,i)),U=Math.max(12,Math.min(n,a)),u.style.left=`${H}px`,u.style.top=`${U}px`});let W=e=>{if(z){z=!1;try{u.releasePointerCapture(e.pointerId)}catch{}}};u.addEventListener(`pointerup`,W),u.addEventListener(`pointercancel`,W),b.appendChild(u),document.body.appendChild(n),T=Date.now(),w=0,x=window.setInterval(()=>{if(!C){let e=w+(Date.now()-T),t=Math.floor(e/1e3);D.textContent=a(t)}},500)}function le(e,t){if(n)return;n=document.createElement(`div`),n.id=`recordflow-overlay-root`,n.style.position=`fixed`,n.style.zIndex=`2147483647`,n.style.pointerEvents=`none`,n.style.top=`0`,n.style.left=`0`,n.style.width=`100vw`,n.style.height=`100vh`,b=n.attachShadow({mode:`open`});let r=document.createElement(`style`);r.textContent=`
        * {
          box-sizing: border-box;
          margin: 0;
          padding: 0;
          font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
          user-select: none;
        }

        .loom-dock {
          position: fixed;
          left: 24px;
          top: 50%;
          transform: translateY(-50%);
          background: rgba(15, 23, 42, 0.94);
          backdrop-filter: blur(24px);
          -webkit-backdrop-filter: blur(24px);
          border: 1.5px solid rgba(255, 255, 255, 0.18);
          border-radius: 36px;
          padding: 10px 8px;
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 10px;
          box-shadow: 
            0 15px 40px rgba(0, 0, 0, 0.65),
            0 0 25px rgba(99, 102, 241, 0.3);
          color: #ffffff;
          pointer-events: auto;
          cursor: grab;
          z-index: 2147483647;
        }

        .loom-dock:active { cursor: grabbing; }

        .btn-stop-dock {
          width: 44px;
          height: 44px;
          border-radius: 50%;
          background: #ef4444;
          border: 2px solid rgba(255, 255, 255, 0.3);
          color: #ffffff;
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
          box-shadow: 0 0 16px rgba(239, 68, 68, 0.7);
          transition: all 0.15s ease;
        }

        .btn-stop-dock:hover {
          transform: scale(1.08);
          background: #dc2626;
          box-shadow: 0 0 22px rgba(239, 68, 68, 0.9);
        }

        .btn-stop-dock svg {
          width: 18px;
          height: 18px;
          fill: currentColor;
          stroke: none;
        }

        .dock-timer-badge {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 3px;
          padding: 2px 4px;
        }

        .rec-dot {
          width: 7px;
          height: 7px;
          background-color: #ef4444;
          border-radius: 50%;
          animation: pulse-dot 1.2s infinite ease-in-out;
          box-shadow: 0 0 8px rgba(239, 68, 68, 0.9);
        }

        @keyframes pulse-dot {
          0%, 100% { opacity: 1; transform: scale(1); }
          50% { opacity: 0.35; transform: scale(0.85); }
        }

        .timer-display {
          font-size: 11.5px;
          font-weight: 800;
          font-variant-numeric: tabular-nums;
          font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
          color: #f8fafc;
          letter-spacing: 0.02em;
        }
      `,b.appendChild(r);let i=document.createElement(`div`);i.className=`loom-dock`;let o=document.createElement(`button`);o.className=`btn-stop-dock`,o.title=`Detener Grabación`,o.innerHTML=y,o.addEventListener(`click`,e=>{e.stopPropagation(),chrome.runtime.sendMessage({type:`STOP_RECORDING_REQUEST`}),J()}),i.appendChild(o);let s=document.createElement(`div`);s.className=`dock-timer-badge`;let c=document.createElement(`span`);c.className=`rec-dot`;let l=document.createElement(`span`);l.className=`timer-display`,l.textContent=`00:00`,s.appendChild(c),s.appendChild(l),i.appendChild(s);let u=!1,d=0,f=0,p=24,m=Math.max(80,window.innerHeight/2-100);i.style.left=`${p}px`,i.style.top=`${m}px`,i.style.transform=`none`,i.addEventListener(`pointerdown`,e=>{e.target.closest(`button`)||(u=!0,d=e.clientX-p,f=e.clientY-m,i.setPointerCapture(e.pointerId))}),i.addEventListener(`pointermove`,e=>{u&&(p=Math.max(12,Math.min(e.clientX-d,window.innerWidth-60)),m=Math.max(12,Math.min(e.clientY-f,window.innerHeight-120)),i.style.left=`${p}px`,i.style.top=`${m}px`)});let h=e=>{if(u){u=!1;try{i.releasePointerCapture(e.pointerId)}catch{}}};i.addEventListener(`pointerup`,h),i.addEventListener(`pointercancel`,h),b.appendChild(i),document.body.appendChild(n),x=window.setInterval(()=>{let t=Math.max(0,Math.floor((Date.now()-e)/1e3));l.textContent=a(t)},500)}async function $(e,n){try{let i=await r();t=[],S=!1,C=!1,M=`m`,N=!1,P=!n;let a;if(e===`camera`){if(B&&B.active&&B.getVideoTracks().some(e=>e.readyState===`live`))D=B;else try{D=await navigator.mediaDevices.getUserMedia({video:{width:{ideal:1280},height:{ideal:720}},audio:n?{echoCancellation:!0,noiseSuppression:!0}:!1})}catch{D=await navigator.mediaDevices.getUserMedia({video:!0,audio:n?{echoCancellation:!0,noiseSuppression:!0}:!1})}return a=D,X(),se(()=>{Y(),ce(D,e,i),ue(a,e)}),{success:!0}}if(O=await navigator.mediaDevices.getDisplayMedia({video:!0,audio:!0}),X(),O.getVideoTracks()[0].onended=()=>{Q(e)},e===`screen-camera`){if(B&&B.active&&B.getVideoTracks().some(e=>e.readyState===`live`))D=B;else try{D=await navigator.mediaDevices.getUserMedia({video:{width:{ideal:1280},height:{ideal:720}},audio:!1})}catch{try{D=await navigator.mediaDevices.getUserMedia({video:!0,audio:!1})}catch{D=null}}}if(n){if(V&&V.active&&V.getAudioTracks().some(e=>e.readyState===`live`))k=V;else try{k=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:!0,noiseSuppression:!0}})}catch{k=null}if(k)try{j=new AudioContext;let e=j.createMediaStreamDestination(),t=O.getAudioTracks();t.length>0&&j.createMediaStreamSource(new MediaStream(t)).connect(e),j.createMediaStreamSource(k).connect(e),a=new MediaStream([...O.getVideoTracks(),...e.stream.getAudioTracks()])}catch{a=O}else a=O}else a=O;return A=a,se(()=>{Y(),ce(D,e,i),ue(a,e)}),{success:!0}}catch(e){return console.warn(`[RecordFlow] Start recording cancelled or failed:`,e),{success:!1,error:e?.message||`USER_CANCELLED`}}}function ue(n,r){let i=ee();e=new MediaRecorder(n,{mimeType:i,videoBitsPerSecond:3e6}),e.ondataavailable=e=>{e.data&&e.data.size>0&&t.push(e.data)},e.onstop=()=>{ae(r)},e.start(1e3)}async function de(e=`screen-camera`,t=!0){if(R){re();return}G=e,K=t,q=e!==`screen`;let n=await r();R=document.createElement(`div`),R.id=`recordflow-hub-host`,R.style.position=`fixed`,R.style.zIndex=`2147483645`;let a=Math.max(10,window.innerWidth-360),o=24;R.style.left=`${a}px`,R.style.top=`${o}px`,R.style.right=`auto`,R.style.pointerEvents=`auto`;let p=R.attachShadow({mode:`open`}),m=document.createElement(`style`);m.textContent=`
        * {
          box-sizing: border-box;
          margin: 0;
          padding: 0;
          font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
          user-select: none;
        }

        .hub-card {
          width: 330px;
          background: rgba(15, 23, 42, 0.94);
          backdrop-filter: blur(24px);
          -webkit-backdrop-filter: blur(24px);
          border: 1.5px solid rgba(255, 255, 255, 0.16);
          border-radius: 24px;
          padding: 18px 20px;
          box-shadow: 
            0 24px 60px rgba(0, 0, 0, 0.7),
            0 0 35px rgba(99, 102, 241, 0.35);
          color: #f8fafc;
          animation: slide-in 0.22s cubic-bezier(0.16, 1, 0.3, 1) forwards;
          display: flex;
          flex-direction: column;
          gap: 14px;
        }

        @keyframes slide-in {
          from {
            opacity: 0;
            transform: translateY(-12px) scale(0.97);
          }
          to {
            opacity: 1;
            transform: translateY(0) scale(1);
          }
        }

        /* Header */
        .hub-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
        }

        .hub-brand {
          display: flex;
          align-items: center;
          gap: 9px;
        }

        .hub-brand-icon {
          width: 28px;
          height: 28px;
          border-radius: 8px;
          background: linear-gradient(135deg, #6366f1 0%, #a855f7 100%);
          display: flex;
          align-items: center;
          justify-content: center;
          color: #ffffff;
          box-shadow: 0 0 12px rgba(99, 102, 241, 0.6);
        }

        .hub-brand-icon svg {
          width: 15px;
          height: 15px;
          stroke: currentColor;
        }

        .hub-brand-info {
          display: flex;
          flex-direction: column;
        }

        .hub-title {
          font-size: 14px;
          font-weight: 800;
          color: #ffffff;
          letter-spacing: -0.01em;
        }

        .hub-badge {
          font-size: 10px;
          font-weight: 600;
          color: #a5b4fc;
        }

        .btn-hub-close {
          background: rgba(255, 255, 255, 0.08);
          border: none;
          color: #94a3b8;
          border-radius: 50%;
          width: 26px;
          height: 26px;
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
          transition: all 0.15s ease;
        }

        .btn-hub-close:hover {
          background: rgba(255, 255, 255, 0.2);
          color: #ffffff;
        }

        .btn-hub-close svg {
          width: 14px;
          height: 14px;
          stroke: currentColor;
        }

        /* Mode Selection Row */
        .hub-modes {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 6px;
          background: rgba(0, 0, 0, 0.35);
          padding: 4px;
          border-radius: 12px;
          border: 1px solid rgba(255, 255, 255, 0.08);
        }

        .hub-mode-btn {
          background: transparent;
          border: none;
          color: #94a3b8;
          padding: 7px 4px;
          border-radius: 8px;
          font-size: 10.5px;
          font-weight: 600;
          cursor: pointer;
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 4px;
          transition: all 0.15s ease;
        }

        .hub-mode-btn svg {
          width: 16px;
          height: 16px;
          stroke: currentColor;
        }

        .hub-mode-btn.active {
          background: rgba(99, 102, 241, 0.3);
          color: #ffffff;
          border: 1px solid rgba(99, 102, 241, 0.5);
          box-shadow: 0 0 10px rgba(99, 102, 241, 0.3);
        }

        /* Audio & VU-meter Row */
        .hub-audio-row {
          display: flex;
          align-items: center;
          justify-content: space-between;
          background: rgba(255, 255, 255, 0.05);
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 12px;
          padding: 8px 12px;
        }

        .hub-audio-left {
          display: flex;
          align-items: center;
          gap: 8px;
          font-size: 11.5px;
          font-weight: 600;
          color: #e2e8f0;
          cursor: pointer;
        }

        .hub-audio-left svg {
          width: 15px;
          height: 15px;
          color: #818cf8;
        }

        .hub-vu-track {
          width: 80px;
          height: 5px;
          background: rgba(255, 255, 255, 0.1);
          border-radius: 9999px;
          overflow: hidden;
        }

        .hub-vu-bar {
          height: 100%;
          width: 0%;
          background: linear-gradient(90deg, #10b981 0%, #6366f1 70%, #ef4444 100%);
          border-radius: 9999px;
          transition: width 0.06s ease-out;
        }

        /* Big Glowing Action Button (Image 2 style) */
        .btn-hub-record {
          width: 100%;
          padding: 13px 18px;
          border-radius: 14px;
          border: none;
          background: linear-gradient(135deg, #f97316 0%, #ef4444 60%, #6366f1 100%);
          color: #ffffff;
          font-size: 14px;
          font-weight: 800;
          letter-spacing: -0.01em;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          cursor: pointer;
          box-shadow: 
            0 8px 24px rgba(239, 68, 68, 0.45),
            0 0 15px rgba(249, 115, 22, 0.3);
          transition: all 0.18s cubic-bezier(0.16, 1, 0.3, 1);
        }

        .btn-hub-record:hover {
          transform: translateY(-1.5px);
          box-shadow: 
            0 12px 28px rgba(239, 68, 68, 0.6),
            0 0 22px rgba(249, 115, 22, 0.45);
        }

        .btn-hub-record:active {
          transform: translateY(0);
        }

        .btn-hub-record svg {
          width: 18px;
          height: 18px;
          fill: currentColor;
          stroke: none;
        }
      `,p.appendChild(m);let h=document.createElement(`div`);h.className=`hub-card`;let _=document.createElement(`div`);_.className=`hub-header`,_.style.cursor=`grab`;let v=document.createElement(`div`);v.className=`hub-brand`,v.innerHTML=`
        <div class="hub-brand-icon">${s}</div>
        <div class="hub-brand-info">
          <span class="hub-title">RecordFlow Studio</span>
          <span class="hub-badge">${i(`unlimited_badge`,n)}</span>
        </div>
      `;let b=document.createElement(`div`);b.style.display=`flex`,b.style.alignItems=`center`,b.style.gap=`6px`;let x=document.createElement(`button`);x.className=`btn-hub-close`,x.title=`Fijar botón en la web`,x.innerHTML=`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width:13px;height:13px"><line x1="12" x2="12" y1="17" y2="22"></line><path d="M5 17h14v-1.76a2 2 0 0 0-1.11-1.79l-1.78-.9A2 2 0 0 1 15 10.76V6h1a2 2 0 0 0 0-4H8a2 2 0 0 0 0 4h1v4.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24Z"></path></svg>`,chrome.storage.local.get(`recordflow_pin_launcher`).then(e=>{e?.recordflow_pin_launcher===!0&&(x.style.color=`#818cf8`,x.style.background=`rgba(99, 102, 241, 0.25)`,x.title=`Desfijar botón de la web`)}),x.addEventListener(`click`,async e=>{e.stopPropagation();let t=!(await chrome.storage.local.get(`recordflow_pin_launcher`))?.recordflow_pin_launcher;await chrome.storage.local.set({recordflow_pin_launcher:t}),t?(x.style.color=`#818cf8`,x.style.background=`rgba(99, 102, 241, 0.25)`,x.title=`Desfijar botón de la web`,fe()):(x.style.color=``,x.style.background=``,x.title=`Fijar botón en la web`,L&&L.parentNode&&(L.parentNode.removeChild(L),L=null))});let S=document.createElement(`button`);S.className=`btn-hub-close`,S.title=`Cerrar`,S.innerHTML=g,S.addEventListener(`click`,e=>{e.stopPropagation(),re()}),b.appendChild(x),b.appendChild(S),_.appendChild(v),_.appendChild(b),h.appendChild(_);let C=!1,w=0,T=0;_.addEventListener(`pointerdown`,e=>{e.target.closest(`button`)||(C=!0,_.style.cursor=`grabbing`,w=e.clientX-a,T=e.clientY-o,_.setPointerCapture(e.pointerId))}),_.addEventListener(`pointermove`,e=>{if(!C)return;let t=e.clientX-w,n=e.clientY-T,r=window.innerWidth-340,i=window.innerHeight-80;a=Math.max(10,Math.min(t,r)),o=Math.max(10,Math.min(n,i)),R.style.left=`${a}px`,R.style.top=`${o}px`});let E=e=>{if(C){C=!1,_.style.cursor=`grab`;try{_.releasePointerCapture(e.pointerId)}catch{}}};_.addEventListener(`pointerup`,E),_.addEventListener(`pointercancel`,E);let D=document.createElement(`div`);D.className=`hub-modes`,[{id:`screen-camera`,label:`Pantalla + Cam`,icon:u},{id:`screen`,label:`Solo Pantalla`,icon:l},{id:`camera`,label:`Solo Cámara`,icon:c}].forEach(e=>{let t=document.createElement(`button`);t.className=`hub-mode-btn ${G===e.id?`active`:``}`,t.innerHTML=`${e.icon}<span>${e.label}</span>`,t.addEventListener(`click`,()=>{G=e.id,D.querySelectorAll(`.hub-mode-btn`).forEach(e=>e.classList.remove(`active`)),t.classList.add(`active`),N()}),D.appendChild(t)}),h.appendChild(D);let O=document.createElement(`div`);O.className=`hub-audio-row`;let k=document.createElement(`div`);k.className=`hub-audio-left`,k.innerHTML=`${d}<span>${i(`audio_mic_label`,n)}</span>`,k.addEventListener(`click`,()=>{K=!K,k.innerHTML=K?`${d}<span>${i(`audio_mic_label`,n)} ON</span>`:`${f}<span>${i(`audio_mic_label`,n)} OFF</span>`,!K&&j&&(j.style.width=`0%`)});let A=document.createElement(`div`);A.className=`hub-vu-track`;let j=document.createElement(`div`);j.className=`hub-vu-bar`,A.appendChild(j),O.appendChild(k),O.appendChild(A),h.appendChild(O);let M=document.createElement(`button`);M.className=`btn-hub-record`,M.innerHTML=`${y}<span>${i(`btn_start_recording`,n)}</span>`,M.addEventListener(`click`,()=>{$(!q&&G===`screen-camera`?`screen`:G,K)}),h.appendChild(M),p.appendChild(h),document.body.appendChild(R);async function N(){if(G===`screen`||!q)Y(),B&&=(B.getTracks().forEach(e=>e.stop()),null);else{if(!B)try{let e=await chrome.storage.local.get(`recordflow_camera_id`),t=typeof e?.recordflow_camera_id==`string`?e.recordflow_camera_id:void 0,n=t?{deviceId:{exact:t}}:{width:{ideal:1280},height:{ideal:720}};try{B=await navigator.mediaDevices.getUserMedia({video:n,audio:!1})}catch{B=await navigator.mediaDevices.getUserMedia({video:!0,audio:!1})}}catch(e){console.warn(`[RecordFlow] Camera access error:`,e),Y();return}B&&ie(B)}}async function P(){if(!K)W&&=(cancelAnimationFrame(W),null),V&&=(V.getTracks().forEach(e=>e.stop()),null);else try{V=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:!0,noiseSuppression:!0}}),H=new AudioContext,U=H.createAnalyser(),U.fftSize=64,U.smoothingTimeConstant=.5,H.createMediaStreamSource(V).connect(U);let e=new Uint8Array(U.frequencyBinCount),t=()=>{if(!U)return;U.getByteFrequencyData(e);let n=0;for(let t=0;t<e.length;t++)n+=e[t];let r=n/e.length,i=Math.min(100,Math.round(r/128*100));j.style.width=`${i}%`,W=requestAnimationFrame(t)};t()}catch{}}N(),P()}function fe(){if(document.getElementById(`recordflow-launcher-host`))return;L=document.createElement(`div`),L.id=`recordflow-launcher-host`,L.style.position=`fixed`,L.style.bottom=`24px`,L.style.left=`24px`,L.style.zIndex=`2147483640`,L.style.pointerEvents=`auto`;let e=L.attachShadow({mode:`open`}),t=document.createElement(`style`);t.textContent=`
        * {
          box-sizing: border-box;
          margin: 0;
          padding: 0;
          font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
          user-select: none;
        }

        .launcher-pill {
          display: flex;
          align-items: center;
          gap: 8px;
          background: rgba(15, 23, 42, 0.92);
          backdrop-filter: blur(16px);
          -webkit-backdrop-filter: blur(16px);
          border: 1.5px solid rgba(99, 102, 241, 0.5);
          border-radius: 9999px;
          padding: 7px 14px 7px 8px;
          cursor: pointer;
          box-shadow: 
            0 10px 30px rgba(0, 0, 0, 0.5),
            0 0 20px rgba(99, 102, 241, 0.35);
          color: #ffffff;
          transition: all 0.2s cubic-bezier(0.16, 1, 0.3, 1);
        }

        .launcher-pill:hover {
          transform: translateY(-2px) scale(1.04);
          border-color: #818cf8;
          box-shadow: 
            0 14px 35px rgba(0, 0, 0, 0.6),
            0 0 28px rgba(99, 102, 241, 0.5);
        }

        .launcher-icon {
          width: 30px;
          height: 30px;
          border-radius: 50%;
          background: linear-gradient(135deg, #6366f1 0%, #a855f7 100%);
          display: flex;
          align-items: center;
          justify-content: center;
          box-shadow: 0 0 10px rgba(99, 102, 241, 0.6);
        }

        .launcher-icon svg {
          width: 16px;
          height: 16px;
          stroke: #ffffff;
        }

        .launcher-text {
          font-size: 12px;
          font-weight: 700;
          letter-spacing: -0.01em;
          color: #f8fafc;
        }

        .launcher-dot {
          width: 6px;
          height: 6px;
          background: #ef4444;
          border-radius: 50%;
          box-shadow: 0 0 6px #ef4444;
        }

        .btn-launcher-dismiss {
          display: none;
          background: transparent;
          border: none;
          color: #94a3b8;
          cursor: pointer;
          padding: 2px;
          margin-left: 2px;
        }

        .btn-launcher-dismiss:hover {
          color: #ffffff;
        }

        .btn-launcher-dismiss svg {
          width: 12px;
          height: 12px;
        }

        .launcher-pill:hover .btn-launcher-dismiss {
          display: flex;
        }
      `,e.appendChild(t);let n=document.createElement(`div`);n.className=`launcher-pill`,n.title=`RecordFlow Studio • Grabar pantalla`,n.innerHTML=`
        <div class="launcher-icon">${s}</div>
        <span class="launcher-text">RecordFlow</span>
        <span class="launcher-dot"></span>
        <button class="btn-launcher-dismiss" title="Ocultar">${g}</button>
      `,n.addEventListener(`click`,async e=>{e.target.closest(`.btn-launcher-dismiss`)?(e.stopPropagation(),await chrome.storage.local.set({recordflow_pin_launcher:!1}),L&&L.parentNode&&(L.parentNode.removeChild(L),L=null)):de()}),e.appendChild(n),document.body.appendChild(L)}async function pe(){try{(await chrome.storage.local.get(`recordflow_pin_launcher`))?.recordflow_pin_launcher===!0&&fe()}catch{}}document.body?pe():window.addEventListener(`DOMContentLoaded`,pe),chrome.runtime.onMessage.addListener((e,t,n)=>{if(e.type===`PING`)return n({pong:!0}),!0;if(e.type===`TOGGLE_FLOATING_HUB`)return de(e.mode||`screen-camera`,e.mic!==!1),n({success:!0}),!0;if(e.type===`START_RECORDING_INTERNAL`)return $(e.mode||`screen-camera`,e.mic!==!1).then(e=>n(e)).catch(e=>n({success:!1,error:e.message})),!0;if(e.type===`STOP_RECORDING_INTERNAL`)return Q(e.mode||`screen-camera`),n({success:!0}),!0;if(e.type===`SYNC_RECORDING_OVERLAY`)return e.isFollower&&le(e.startTime||Date.now(),e.mode||`screen-camera`),n({success:!0}),!0;if(e.type===`REMOVE_RECORDING_OVERLAY`)return J(),n({success:!0}),!0})}}),x={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)},S=globalThis.browser?.runtime?.id?globalThis.browser:globalThis.chrome,C=class e extends Event{static EVENT_NAME=w(`wxt:locationchange`);constructor(t,n){super(e.EVENT_NAME,{}),this.newUrl=t,this.oldUrl=n}};function w(e){return`${S?.runtime?.id}:content:${e}`}var T=typeof globalThis.navigation?.addEventListener==`function`;function E(e){let t,n=!1;return{run(){n||(n=!0,t=new URL(location.href),T?globalThis.navigation.addEventListener(`navigate`,e=>{let n=new URL(e.destination.url);n.href!==t.href&&(window.dispatchEvent(new C(n,t)),t=n)},{signal:e.signal}):e.setInterval(()=>{let e=new URL(location.href);e.href!==t.href&&(window.dispatchEvent(new C(e,t)),t=e)},1e3))}}}var D=class e{static SCRIPT_STARTED_MESSAGE_TYPE=w(`wxt:content-script-started`);id;abortController;locationWatcher=E(this);constructor(e,t){this.contentScriptName=e,this.options=t,this.id=Math.random().toString(36).slice(2),this.abortController=new AbortController,this.stopOldScripts(),this.listenForNewerScripts()}get signal(){return this.abortController.signal}abort(e){return this.abortController.abort(e)}get isInvalid(){return S.runtime?.id??this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(e){return this.signal.addEventListener(`abort`,e),()=>this.signal.removeEventListener(`abort`,e)}block(){return new Promise(()=>{})}setInterval(e,t){let n=setInterval(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearInterval(n)),n}setTimeout(e,t){let n=setTimeout(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearTimeout(n)),n}requestAnimationFrame(e){let t=requestAnimationFrame((...t)=>{this.isValid&&e(...t)});return this.onInvalidated(()=>cancelAnimationFrame(t)),t}requestIdleCallback(e,t){let n=requestIdleCallback((...t)=>{this.signal.aborted||e(...t)},t);return this.onInvalidated(()=>cancelIdleCallback(n)),n}addEventListener(e,t,n,r){t===`wxt:locationchange`&&this.isValid&&this.locationWatcher.run(),e.addEventListener?.(t.startsWith(`wxt:`)?w(t):t,n,{...r,signal:this.signal})}notifyInvalidated(){this.abort(`Content script context invalidated`),x.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){document.dispatchEvent(new CustomEvent(e.SCRIPT_STARTED_MESSAGE_TYPE,{detail:{contentScriptName:this.contentScriptName,messageId:this.id}})),this.options?.noScriptStartedPostMessage||window.postMessage({type:e.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName,messageId:this.id},`*`)}verifyScriptStartedEvent(e){let t=e.detail?.contentScriptName===this.contentScriptName,n=e.detail?.messageId===this.id;return t&&!n}listenForNewerScripts(){let t=e=>{e instanceof CustomEvent&&this.verifyScriptStartedEvent(e)&&this.notifyInvalidated()};document.addEventListener(e.SCRIPT_STARTED_MESSAGE_TYPE,t),this.onInvalidated(()=>document.removeEventListener(e.SCRIPT_STARTED_MESSAGE_TYPE,t))}},O={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)};return(async()=>{try{let{main:e,...t}=b;return await e(new D(`content`,t))}catch(e){throw O.error(`The content script "content" crashed on startup!`,e),e}})()})();
content;