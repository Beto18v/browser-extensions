(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),t.credentials=e.crossOrigin===`use-credentials`?`include`:e.crossOrigin===`anonymous`?`omit`:`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();var e=`RecordFlowDB`,t=1,n=`recordings`;function r(){return new Promise((r,i)=>{let a=indexedDB.open(e,t);a.onupgradeneeded=e=>{let t=e.target.result;t.objectStoreNames.contains(n)||t.createObjectStore(n,{keyPath:`id`}).createIndex(`timestamp`,`timestamp`,{unique:!1})},a.onsuccess=()=>r(a.result),a.onerror=()=>i(a.error)})}async function i(e){let t=await r();return new Promise((r,i)=>{let a=t.transaction(n,`readwrite`).objectStore(n).put(e);a.onsuccess=()=>r(),a.onerror=()=>i(a.error)})}async function a(e){let t=await r();return new Promise((r,i)=>{let a=t.transaction(n,`readonly`).objectStore(n).get(e);a.onsuccess=()=>r(a.result||null),a.onerror=()=>i(a.error)})}async function o(){let e=await r();return new Promise((t,r)=>{let i=e.transaction(n,`readonly`).objectStore(n).openCursor(null,`prev`),a=[];i.onsuccess=e=>{let n=e.target.result;if(n){let e=n.value;a.push({id:e.id,title:e.title,timestamp:e.timestamp,duration:e.duration,size:e.size,mode:e.mode,mimeType:e.mimeType}),n.continue()}else t(a)},i.onerror=()=>r(i.error)})}async function s(e,t){let n=await a(e);n&&(n.title=t,await i(n))}async function c(e){let t=await r();return new Promise((r,i)=>{let a=t.transaction(n,`readwrite`).objectStore(n).delete(e);a.onsuccess=()=>r(),a.onerror=()=>i(a.error)})}var l={es:{app_name:`RecordFlow`,app_tagline:`Grabador local e ilimitado de pantalla y cámara`,unlimited_badge:`100% Local • Ilimitado`,loom_alt:`Alternativa Libre a Loom`,status_ready:`Listo`,status_recording:`Grabando`,tab_record:`Grabador`,tab_recent:`Grabaciones Recientes`,mode_screen_camera:`Pantalla + Cámara`,mode_screen_only:`Solo Pantalla`,mode_camera_only:`Solo Cámara`,mode_screen_camera_desc:`Graba la pantalla con tu cámara en burbuja circular flotante`,mode_screen_only_desc:`Graba toda la pantalla, ventana o pestaña seleccionada`,mode_camera_only_desc:`Graba exclusivamente tu cámara web`,audio_mic_label:`Micrófono`,audio_mic_active:`Activo`,audio_mic_muted:`Silenciado`,audio_mic_desc:`Incluir voz desde el micrófono en la grabación`,btn_start_recording:`Iniciar Grabación`,btn_stop_recording:`Detener Grabación`,btn_finish_recording:`Finalizar`,btn_cancel:`Cancelar`,btn_download_video:`Descargar Video (.webm)`,btn_copy_link:`Copiar Enlace Local`,btn_link_copied:`¡Enlace copiado!`,btn_record_new:`Grabar Nuevo Video`,btn_delete:`Eliminar`,btn_rename:`Renombrar`,btn_save:`Guardar`,floating_recording:`REC`,floating_finish:`Finalizar`,no_recordings_title:`No hay grabaciones guardadas`,no_recordings_desc:`Tus videos se guardan 100% en tu navegador, sin límites ni nubes de terceros.`,meta_duration:`Duración`,meta_size:`Tamaño`,meta_date:`Fecha`,meta_mode:`Modo`,confirm_delete:`¿Estás seguro de que deseas eliminar esta grabación? Esta acción no se puede deshacer.`,preview_header_title:`RecordFlow Studio`,preview_subtitle:`Grabación completada con éxito • Almacenamiento local`,preview_player_title:`Reproductor de Video`,preview_file_details:`Detalles del Archivo`,preview_all_recordings:`Tus Grabaciones Guardadas`,preview_format:`Formato WebM de alta fidelidad`,err_restricted_page:`Por favor abre una página web regular (HTTP/HTTPS) para grabar.`,err_permission_denied:`Permiso de pantalla o cámara denegado.`,err_recording_failed:`Ocurrió un error al iniciar la grabación.`,notice_recording_active:`Grabación en curso en la pestaña activa...`,universal_studio_title:`RecordFlow Studio — Grabador Universal`,universal_studio_subtitle:`Graba cualquier pantalla, ventana o aplicación del equipo`,universal_status_recording:`🔴 Grabando pantalla...`,universal_instructions:`Puedes minimizar esta pestaña y trabajar en cualquier aplicación de tu equipo (VS Code, terminal, juegos, etc.). Cuando termines, haz clic en Detener o usa el botón 'Dejar de compartir' de Chrome.`,universal_btn_stop_save:`⏹️ Detener y Guardar Grabación`,universal_prompt_title:`Estudio de Grabación Universal`,universal_prompt_desc:`Graba cualquier aplicación, ventana o tu pantalla completa sin restricciones.`,universal_btn_start_share:`🚀 Seleccionar Pantalla y Comenzar`,universal_cancelled_title:`Selección Cancelada`,universal_cancelled_desc:`No se seleccionó ninguna pantalla o se canceló el permiso. Puedes reintentar cuando desees.`,universal_btn_retry:`🔄 Reintentar Selección`,open_universal_studio:`O abrir Estudio Universal para grabar cualquier app`,developed_by:`Desarrollado por`},en:{app_name:`RecordFlow`,app_tagline:`Local-first & unlimited screen and camera recorder`,unlimited_badge:`100% Local • Unlimited`,loom_alt:`Free Loom Alternative`,status_ready:`Ready`,status_recording:`Recording`,tab_record:`Recorder`,tab_recent:`Recent Recordings`,mode_screen_camera:`Screen + Camera`,mode_screen_only:`Screen Only`,mode_camera_only:`Camera Only`,mode_screen_camera_desc:`Record screen with circular floating webcam bubble`,mode_screen_only_desc:`Record full screen, window, or selected tab`,mode_camera_only_desc:`Record webcam video exclusively`,audio_mic_label:`Microphone`,audio_mic_active:`Active`,audio_mic_muted:`Muted`,audio_mic_desc:`Include voice from microphone in recording`,btn_start_recording:`Start Recording`,btn_stop_recording:`Stop Recording`,btn_finish_recording:`Finish`,btn_cancel:`Cancel`,btn_download_video:`Download Video (.webm)`,btn_copy_link:`Copy Local Link`,btn_link_copied:`Link copied!`,btn_record_new:`Record New Video`,btn_delete:`Delete`,btn_rename:`Rename`,btn_save:`Save`,floating_recording:`REC`,floating_finish:`Finish`,no_recordings_title:`No saved recordings yet`,no_recordings_desc:`Your videos are saved 100% locally in your browser with zero caps.`,meta_duration:`Duration`,meta_size:`Size`,meta_date:`Date`,meta_mode:`Mode`,confirm_delete:`Are you sure you want to delete this recording? This action cannot be undone.`,preview_header_title:`RecordFlow Studio`,preview_subtitle:`Recording finished successfully • Local storage`,preview_player_title:`Video Player`,preview_file_details:`File Details`,preview_all_recordings:`Your Saved Recordings`,preview_format:`High-fidelity WebM container`,err_restricted_page:`Please navigate to a regular web page (HTTP/HTTPS) to record.`,err_permission_denied:`Screen or camera permission was denied.`,err_recording_failed:`An error occurred while starting the recording.`,notice_recording_active:`Recording in progress on active tab...`,universal_studio_title:`RecordFlow Studio — Universal Recorder`,universal_studio_subtitle:`Record any screen, window, or desktop application`,universal_status_recording:`🔴 Recording screen...`,universal_instructions:`You can minimize this tab and work in any application on your computer (VS Code, terminal, games, etc.). When you're done, click Stop or use Chrome's 'Stop sharing' button.`,universal_btn_stop_save:`⏹️ Stop and Save Recording`,universal_prompt_title:`Universal Studio Recorder`,universal_prompt_desc:`Record any application, window, or your entire screen without page restrictions.`,universal_btn_start_share:`🚀 Select Screen & Start`,universal_cancelled_title:`Selection Cancelled`,universal_cancelled_desc:`No screen was selected or permission was cancelled. You can retry whenever you are ready.`,universal_btn_retry:`🔄 Retry Selection`,open_universal_studio:`Or open Universal Studio to record any app`,developed_by:`Developed by`}},u=`recordflow_lang`;async function d(){try{let e=await chrome.storage.local.get(u);if(e[u]===`es`||e[u]===`en`)return e[u]}catch{}return navigator.language.toLowerCase().startsWith(`es`)?`es`:`en`}async function f(e){await chrome.storage.local.set({[u]:e})}function p(e,t=`es`){return l[t]?.[e]||l.en[e]||e}function m(e){let t=Math.floor(e/60),n=Math.floor(e%60);return`${t.toString().padStart(2,`0`)}:${n.toString().padStart(2,`0`)}`}function h(e){if(e===0)return`0 B`;let t=1024,n=[`B`,`KB`,`MB`,`GB`],r=Math.floor(Math.log(e)/Math.log(t));return`${parseFloat((e/t**r).toFixed(1))} ${n[r]}`}function g(e,t=`es`){return new Date(e).toLocaleString(t===`es`?`es-ES`:`en-US`,{month:`short`,day:`numeric`,hour:`2-digit`,minute:`2-digit`})}var _=class extends HTMLElement{static get observedAttributes(){return[`lang`]}_lang=`es`;_boundOnLangChange;constructor(){super(),this.attachShadow({mode:`open`}),this._boundOnLangChange=e=>{let t=e.detail?.lang;(t===`es`||t===`en`)&&(this.lang=t)}}get lang(){return this._lang}set lang(e){let t=e===`en`?`en`:`es`;(this._lang!==t||this.getAttribute(`lang`)!==t)&&(this._lang=t,this.getAttribute(`lang`)!==t&&this.setAttribute(`lang`,t),this.render())}setLang(e){this.lang=e}attributeChangedCallback(e,t,n){if(e===`lang`&&t!==n&&n){let e=n===`en`?`en`:`es`;this._lang!==e&&(this._lang=e,this.render())}}async connectedCallback(){let e=this.getAttribute(`lang`);if(e===`es`||e===`en`)this._lang=e;else try{if(typeof chrome<`u`&&chrome.storage?.local){let e=await chrome.storage.local.get([`app_lang`]);(e?.app_lang===`es`||e?.app_lang===`en`)&&(this._lang=e.app_lang)}}catch{}this.render(),window.addEventListener(`langchange`,this._boundOnLangChange)}disconnectedCallback(){window.removeEventListener(`langchange`,this._boundOnLangChange)}render(){if(!this.shadowRoot)return;let e=this._lang===`es`?`Desarrollado por`:`Built by`;this.shadowRoot.innerHTML=`
      <style>
        :host {
          display: block;
          width: 100%;
          box-sizing: border-box;
        }
        *, *::before, *::after {
          box-sizing: inherit;
        }
        .footer-branding {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 5px;
          font-size: 11px;
          color: var(--text-muted, #8b949e);
          padding-top: 10px;
          border-top: 1px dashed var(--border-subtle, rgba(255, 255, 255, 0.08));
          font-family: inherit;
          text-align: center;
        }
        .footer-branding a {
          color: var(--accent-color, #14b8a6);
          text-decoration: none;
          font-weight: 600;
          transition: color 0.15s ease, opacity 0.15s ease;
        }
        .footer-branding a:hover {
          text-decoration: underline;
          opacity: 0.9;
        }
      </style>
      <footer class="footer-branding">
        <span>${e}</span>
        <a href="https://nival.is-a.dev/" target="_blank" rel="noopener noreferrer">Nicolás Valenzuela</a>
      </footer>
    `}};customElements.get(`nival-footer`)||customElements.define(`nival-footer`,_);var v=class extends HTMLElement{static get observedAttributes(){return[`lang`]}_lang=`es`;_boundOnLangChange;constructor(){super(),this.attachShadow({mode:`open`}),this._boundOnLangChange=e=>{let t=e.detail?.lang;(t===`es`||t===`en`)&&this._lang!==t&&(this._lang=t,this.render())}}get lang(){return this._lang}set lang(e){let t=e===`en`?`en`:`es`;(this._lang!==t||this.getAttribute(`lang`)!==t)&&(this._lang=t,this.getAttribute(`lang`)!==t&&this.setAttribute(`lang`,t),this.render())}setLang(e){this.lang=e}attributeChangedCallback(e,t,n){if(e===`lang`&&t!==n&&n){let e=n===`en`?`en`:`es`;this._lang!==e&&(this._lang=e,this.render())}}async connectedCallback(){let e=this.getAttribute(`lang`);if(e===`es`||e===`en`)this._lang=e;else try{if(typeof chrome<`u`&&chrome.storage?.local){let e=await chrome.storage.local.get([`app_lang`]);(e?.app_lang===`es`||e?.app_lang===`en`)&&(this._lang=e.app_lang)}}catch{}this.render(),window.addEventListener(`langchange`,this._boundOnLangChange)}disconnectedCallback(){window.removeEventListener(`langchange`,this._boundOnLangChange)}async toggleLang(){let e=this._lang===`es`?`en`:`es`;this._lang=e,this.getAttribute(`lang`)!==e&&this.setAttribute(`lang`,e),this.render();try{typeof chrome<`u`&&chrome.storage?.local&&await chrome.storage.local.set({app_lang:e})}catch{}window.dispatchEvent(new CustomEvent(`langchange`,{bubbles:!0,composed:!0,detail:{lang:e}}))}render(){if(!this.shadowRoot)return;let e=this._lang.toUpperCase();this.shadowRoot.innerHTML=`
      <style>
        :host {
          display: inline-flex;
          vertical-align: middle;
        }
        .lang-pill {
          display: inline-flex;
          align-items: center;
          gap: 4px;
          background: rgba(255, 255, 255, 0.05);
          border: 1px solid var(--border-subtle, rgba(255, 255, 255, 0.12));
          border-radius: 9999px;
          padding: 3px 8px;
          font-size: 11px;
          font-weight: 600;
          color: var(--text-muted, #8b949e);
          cursor: pointer;
          transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
          user-select: none;
          font-family: inherit;
          line-height: 1.2;
          outline: none;
        }
        .lang-pill:hover {
          background: rgba(255, 255, 255, 0.1);
          color: var(--accent-color, #14b8a6);
          border-color: var(--accent-color, #14b8a6);
          transform: translateY(-1px);
        }
        .lang-pill:active {
          transform: translateY(0);
        }
        .lang-text {
          font-size: 11px;
          font-weight: 700;
          letter-spacing: 0.5px;
        }
      </style>
      <button type="button" class="lang-pill" title="Cambiar idioma / Switch language" aria-label="Toggle language">
        🌐 <span class="lang-text">${e}</span>
      </button>
    `;let t=this.shadowRoot.querySelector(`button`);t&&t.addEventListener(`click`,()=>{this.toggleLang()})}};customElements.get(`nival-lang-switch`)||customElements.define(`nival-lang-switch`,v);export{f as a,o as c,s as d,d as i,a as l,g as n,p as o,m as r,c as s,h as t,i as u};