(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),t.credentials=e.crossOrigin===`use-credentials`?`include`:e.crossOrigin===`anonymous`?`omit`:`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();var e=class extends HTMLElement{static get observedAttributes(){return[`lang`]}_lang=`es`;_boundOnLangChange;constructor(){super(),this.attachShadow({mode:`open`}),this._boundOnLangChange=e=>{let t=e.detail?.lang;(t===`es`||t===`en`)&&(this.lang=t)}}get lang(){return this._lang}set lang(e){let t=e===`en`?`en`:`es`;(this._lang!==t||this.getAttribute(`lang`)!==t)&&(this._lang=t,this.getAttribute(`lang`)!==t&&this.setAttribute(`lang`,t),this.render())}setLang(e){this.lang=e}attributeChangedCallback(e,t,n){if(e===`lang`&&t!==n&&n){let e=n===`en`?`en`:`es`;this._lang!==e&&(this._lang=e,this.render())}}async connectedCallback(){let e=this.getAttribute(`lang`);if(e===`es`||e===`en`)this._lang=e;else try{if(typeof chrome<`u`&&chrome.storage?.local){let e=await chrome.storage.local.get([`app_lang`]);(e?.app_lang===`es`||e?.app_lang===`en`)&&(this._lang=e.app_lang)}}catch{}this.render(),window.addEventListener(`langchange`,this._boundOnLangChange)}disconnectedCallback(){window.removeEventListener(`langchange`,this._boundOnLangChange)}render(){if(!this.shadowRoot)return;let e=this._lang===`es`?`Desarrollado por`:`Built by`;this.shadowRoot.innerHTML=`
      <style>
        :host {
          display: block;
          width: 100%;
          box-sizing: border-box;
        }
        *, *::before, *::after {
          box-sizing: inherit;
        }
        .footer-branding {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 5px;
          font-size: 11px;
          color: var(--text-muted, #8b949e);
          padding-top: 10px;
          border-top: 1px dashed var(--border-subtle, rgba(255, 255, 255, 0.08));
          font-family: inherit;
          text-align: center;
        }
        .footer-branding a {
          color: var(--accent-color, #14b8a6);
          text-decoration: none;
          font-weight: 600;
          transition: color 0.15s ease, opacity 0.15s ease;
        }
        .footer-branding a:hover {
          text-decoration: underline;
          opacity: 0.9;
        }
      </style>
      <footer class="footer-branding">
        <span>${e}</span>
        <a href="https://nival.is-a.dev/" target="_blank" rel="noopener noreferrer">Nicolás Valenzuela</a>
      </footer>
    `}};customElements.get(`nival-footer`)||customElements.define(`nival-footer`,e);var t=class extends HTMLElement{static get observedAttributes(){return[`lang`]}_lang=`es`;_boundOnLangChange;constructor(){super(),this.attachShadow({mode:`open`}),this._boundOnLangChange=e=>{let t=e.detail?.lang;(t===`es`||t===`en`)&&this._lang!==t&&(this._lang=t,this.render())}}get lang(){return this._lang}set lang(e){let t=e===`en`?`en`:`es`;(this._lang!==t||this.getAttribute(`lang`)!==t)&&(this._lang=t,this.getAttribute(`lang`)!==t&&this.setAttribute(`lang`,t),this.render())}setLang(e){this.lang=e}attributeChangedCallback(e,t,n){if(e===`lang`&&t!==n&&n){let e=n===`en`?`en`:`es`;this._lang!==e&&(this._lang=e,this.render())}}async connectedCallback(){let e=this.getAttribute(`lang`);if(e===`es`||e===`en`)this._lang=e;else try{if(typeof chrome<`u`&&chrome.storage?.local){let e=await chrome.storage.local.get([`app_lang`]);(e?.app_lang===`es`||e?.app_lang===`en`)&&(this._lang=e.app_lang)}}catch{}this.render(),window.addEventListener(`langchange`,this._boundOnLangChange)}disconnectedCallback(){window.removeEventListener(`langchange`,this._boundOnLangChange)}async toggleLang(){let e=this._lang===`es`?`en`:`es`;this._lang=e,this.getAttribute(`lang`)!==e&&this.setAttribute(`lang`,e),this.render();try{typeof chrome<`u`&&chrome.storage?.local&&await chrome.storage.local.set({app_lang:e})}catch{}window.dispatchEvent(new CustomEvent(`langchange`,{bubbles:!0,composed:!0,detail:{lang:e}}))}render(){if(!this.shadowRoot)return;let e=this._lang.toUpperCase();this.shadowRoot.innerHTML=`
      <style>
        :host {
          display: inline-flex;
          vertical-align: middle;
        }
        .lang-pill {
          display: inline-flex;
          align-items: center;
          gap: 4px;
          background: rgba(255, 255, 255, 0.05);
          border: 1px solid var(--border-subtle, rgba(255, 255, 255, 0.12));
          border-radius: 9999px;
          padding: 3px 8px;
          font-size: 11px;
          font-weight: 600;
          color: var(--text-muted, #8b949e);
          cursor: pointer;
          transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
          user-select: none;
          font-family: inherit;
          line-height: 1.2;
          outline: none;
        }
        .lang-pill:hover {
          background: rgba(255, 255, 255, 0.1);
          color: var(--accent-color, #14b8a6);
          border-color: var(--accent-color, #14b8a6);
          transform: translateY(-1px);
        }
        .lang-pill:active {
          transform: translateY(0);
        }
        .lang-text {
          font-size: 11px;
          font-weight: 700;
          letter-spacing: 0.5px;
        }
      </style>
      <button type="button" class="lang-pill" title="Cambiar idioma / Switch language" aria-label="Toggle language">
        🌐 <span class="lang-text">${e}</span>
      </button>
    `;let t=this.shadowRoot.querySelector(`button`);t&&t.addEventListener(`click`,()=>{this.toggleLang()})}};customElements.get(`nival-lang-switch`)||customElements.define(`nival-lang-switch`,t),document.addEventListener(`DOMContentLoaded`,async()=>{let e=document.getElementById(`global-toggle`),t=document.getElementById(`site-toggle`),n=document.getElementById(`site-label`),r=document.getElementById(`site-sublabel`),i=document.getElementById(`global-label`),a=document.getElementById(`global-sublabel`),o=document.getElementById(`shortcut-label`),s=`es`;try{let e=await chrome.storage.local.get([`app_lang`]);(e?.app_lang===`en`||e?.app_lang===`es`)&&(s=e.app_lang)}catch{}let c={es:{globalLabel:`Dark Mode Global`,globalSublabel:`Activar en toda la web`,siteLabel:`Sitio actual`,siteDetecting:`detectando...`,notAvailable:`No disponible`,internalPage:`Página interna`,shortcut:`Atajo rápido:`},en:{globalLabel:`Global Dark Mode`,globalSublabel:`Activate across the web`,siteLabel:`Current site`,siteDetecting:`detecting...`,notAvailable:`Not available`,internalPage:`Internal page`,shortcut:`Quick shortcut:`}},l=``,u=!1;function d(){let e=c[s];i&&(i.textContent=e.globalLabel),a&&(a.textContent=e.globalSublabel),o&&(o.textContent=e.shortcut),u?(n&&(n.textContent=e.notAvailable),r&&(r.textContent=l||e.internalPage)):(n&&(n.textContent=e.siteLabel),r&&(r.textContent=l||e.siteDetecting))}window.addEventListener(`langchange`,e=>{let t=e;t.detail?.lang&&(t.detail.lang===`es`||t.detail.lang===`en`)&&(s=t.detail.lang,d())});let[f]=await chrome.tabs.query({active:!0,currentWindow:!0});if(f?.url)try{let e=new URL(f.url);l=e.hostname,[`http:`,`https:`].includes(e.protocol)||(u=!0)}catch{u=!0}else u=!0;async function p(e){f?.id&&!u&&chrome.tabs.sendMessage(f.id,e).catch(()=>{})}u&&(t.disabled=!0,t.checked=!1),d();let m=await chrome.storage.local.get([`eclipse_enabled`,`eclipse_disabled_sites`]),h=m.eclipse_enabled!==!1,g=(m.eclipse_disabled_sites||[]).some(e=>l===e||l.endsWith(`.${e}`));e.checked=h,u||(t.checked=!g),e.addEventListener(`change`,async()=>{let t=e.checked;p({type:`ECLIPSE_SET_STATE`,globalEnabled:t}),await chrome.storage.local.set({eclipse_enabled:t})}),t.addEventListener(`change`,async()=>{if(u||!l)return;let e=t.checked;p({type:`ECLIPSE_SET_STATE`,siteEnabled:e});let n=(await chrome.storage.local.get([`eclipse_disabled_sites`])).eclipse_disabled_sites||[];e?n=n.filter(e=>e!==l&&!l.endsWith(`.${e}`)):n.includes(l)||n.push(l),await chrome.storage.local.set({eclipse_disabled_sites:n})})});